let game_hello () = print_endline "Hello, Newtonoiders!"
